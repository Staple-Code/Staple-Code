<!DOCTYPE html>
<html>
	<head>
		<title>Staple Code</title>
	</head>
	<body>
		<h1>Staple Code</h1>