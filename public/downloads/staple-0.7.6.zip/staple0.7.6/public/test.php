<?php
phpinfo();
echo 'Key:'.getenv('STAPLE_ENCRYPT_KEY');