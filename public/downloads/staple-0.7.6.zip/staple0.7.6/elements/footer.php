			</div>
		</div> 
		<div id="footer">
			<ul>
				<li><a href="">Home</a></li> |
				<li><a href="<?php echo $this->link(array('tutorial','index'));?>">Tutorial</a></li> |
				<li><a href="">Documentation</a></li> |
				<li><a href="">Download</a></li> |
				<li><a href="">About</a></li>
			</ul>
		</div>
	</body>
</html>